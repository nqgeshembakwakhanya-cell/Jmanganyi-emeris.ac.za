package com.mycompany.questionone;
public class Questionone {

    public static void main(String[] args) {
       int[][] scores = new int[3][4];
       String[] Gamming = {" ","", "PS5", "XBOX", "SWITCH"};
        String[] province = {"Cape town", "Port elizabeth", "Pretoria"};
        int[][] numbers = {{1000,2000,3000}, {2000,3000,4000}, {15000,1100,1200}};
        int[][] totals = {{6000,9000,3800}};
        System.out.println("------------------------------------------");
        System.out.println("Gamming console report");
        System.out.println("-------------------------------------------");
        
        for (int i = 0; i < Gamming.length; i++) {//OPENING FOR-loop
            System.out.print("" + Gamming[i] + "\t");
        }//close For-loop
        System.out.println();
        
       for (int outer = 0; outer < province.length; outer++) {//opening out
            System.out.print(province[outer] + "\t");

            //inner loop
            for (int inner = 0; inner < numbers[outer].length; inner++) {//open inner
                System.out.print(numbers[outer][inner] + "\t");
            }//close inner  
            System.out.println("");
       }// CLOSE outter loop
       System.out.println("------------------------------------------");
        System.out.println("CONSOLE SALES TOTALS FOR EACH CITY");
        System.out.println("-------------------------------------------");
        
        for (int i = 0; i < province.length; i++) {//OPENING FOR-loop
            System.out.print("" + province[i] + "\t");
           for (int[] total : totals) {
               System.out.println(" 6000,9000,3800");
           }
        }//close For-loop  
  
        
    }//close static class
}// close public class
